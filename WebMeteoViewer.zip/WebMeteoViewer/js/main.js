var Main = {
    paths: {},
    htmlTemplate: {},
    data: [],
    orp: [],
    mapSvgDocument: null,
    compassSvgDocument: null,
    svgMap: null,
    results: [],
    orpSelected: {
        name: "",
        direction: ""
    },
    init: function(paths) {
        this.paths = paths;
        let results = [
            this.loadComponents(),
            this.loadData(),
            this.loadOrp(),
            this.loadSvg({
                container: "svgmap",
                path: this.paths.svgMap,
                width: "95%",
                height: "auto"
            }),
            this.loadSvg({
                container: "svgcompass",
                path: this.paths.svgCompass,
                width: "100px",
                height: "100px"
            }),
        ];
        $.when.apply($, results).done(function() {
            Main.run();
        });
        console.log(this.paths);
    },
    loadComponents: function() {
        let results = [];
        $.each(this.paths.components, function(k,v) {
            results.push(Main.comp(v));
       });
       return $.when.apply($, results);
    },
    loadSvg: function(obj) {
        $("#"+obj.container).html('<object id="obj-'+obj.container+'" type="image/svg+xml" data="./data/' + obj.path + '" width="'+obj.width+'" height="'+obj.height+'" />');
        return true;
    },
    comp: function(v) {
        return $.get("./components/"+v, function(html_string) {
            Main.htmlTemplate[v.replace(".html","")] = html_string;
        },'html');
    },
    loadData: function() {
        return $.getJSON("./data/"+this.paths.data, function(data) {
            Main.data = data;
        });
    },
    loadOrp: function() {
        return $.getJSON("./data/"+this.paths.orp, function(data) {
            Main.orp = data;
        });
    },
    run: function() {
        document.getElementById("obj-svgmap").addEventListener("load", function () {
            Main.mapSvgDocument = this.getSVGDocument();
            Main.runAll();
        });
    },
    runAll: function() {
        Main.compassSvgDocument =  document.getElementById("obj-svgcompass");
        $.each(Main.data.data, function(k,v) {
            $(Main.mapSvgDocument).find('path[id="'+k+'"]').css("fill-opacity", "0.1");
            $(Main.mapSvgDocument).find('path[id="'+k+'"]').css("fill", Main.orp.outputresultcolor[v+1]);
            $(Main.mapSvgDocument).find('path[id="'+k+'"]').click(Main.onClickOrp);
        });
        Main.compass();
        Main.bgWrf();
        Main.updateORP("Zlín", 2);
        Main.updateORP("Aš", 2);
        Main.updateORP("Mohelnice", 2);                
    },
    compass: function() {
    ///    $("#wrap-compass").hide();
        let arrow = function(k, active) {
            let color = active?Setup.directionColorActive:"#000";
            $(Main.compassSvgDocument).find('g[id="'+k+'"]').children("path").css("stroke", color);
            $(Main.compassSvgDocument).find('g[id="'+k+'"]').children("circle").css("fill", color);
            $(Main.compassSvgDocument).find('g[id="'+k+'"]').children("ellipse").css("fill", color);
        }
        let reset = function() {
            $.each(Setup.direction, function(k,item) {
                arrow(item, false);
            })
        }
        reset();
        $.each(Setup.direction, function(k,item) {
            $(Main.compassSvgDocument).find('g[id="'+item+'"]').hover(function(){        
                reset();            
                arrow(item, true);
                Main.orpSelected.direction = item;
                Main.onHoverDirection();
            },function(){        
                reset();            
            }).click(function() {
                Main.orpSelected.direction = item;
                Main.updateCompass();
            }).css("cursor","pointer");
        });
    },
    bgWrf: function() {
        let $elem = $("#wrap-map");
        $elem.prepend('<img  src="./data/'+this.data.wrf+'" style="width:100%">');
    },
    updateCompass: function() {
        let $elem = $("#wrap-compass");
        $elem.show();
        $elem.children("span").html(Main.orpSelected.name+': '+Main.orpSelected.direction);
        this.compass();
    },
    updateORP: function(name, value){
        $(this.mapSvgDocument).find("title:contains('" + name + "')").parent().css("fill", Main.orp.outputresultcolor[value]);
        $(this.mapSvgDocument).find("title:contains('" + name + "')").parent().css("fill-opacity", 1);
        $(this.mapSvgDocument).find("title:contains('" + name + "')").parent().css("value", value);
    },
    onClickOrp: function() {
        Main.orpSelected.name = $(this).find("title").text();
        Main.orpSelected.direction = "";
        Main.updateCompass();
    },
    onHoverDirection: function() {
        let name = Main.orpSelected.name;
        if(name=="") return;
        try {
            Main.updateORP(name, Main.data.regions[name][Main.orpSelected.direction]);
        } catch(e) {
            alert("Pro region "+name+" nejsou data k dispozici");
        }
        return;
    }

}