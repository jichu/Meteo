$.urlVar=function(n){var e=new RegExp("[?]"+n+"([^&#]*)").test(window.location.href);return e};
String.prototype.ucfirst = function(){return this.charAt(0).toUpperCase()+this.slice(1);};
$.getMultiScripts=function(arr,path){var _arr=$.map(arr,function(scr){return $.getScript((path||"")+scr)});_arr.push($.Deferred(function(deferred){$(deferred.resolve)}));return $.when.apply($,_arr)}

var _seed = Math.round(new Date().getTime()/1000);

$.getJSON("data/paths.json?" + _seed, function (json) {
    $.getMultiScripts(json.js, "js/").done(function () {
        Main.init(json);        
    });
});