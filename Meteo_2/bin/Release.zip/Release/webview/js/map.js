try {
    var Map = {
        mapSvgDocument: null,
        data: null,
        position: {},
        lockPos: false,
        load: function(data) {
            this.data = data;
            Main.view("map");
            let results = [
                this.loadSvg({
                    container: "svgmap",
                    path: Main.paths.svgMap,
                    width: "95%",
                    height: "auto"
                })
            ];
            $.when.apply($, results).done(function() {                
                document.getElementById("obj-svgmap").addEventListener("load", function () {
                    Map.mapSvgDocument = this.getSVGDocument();
                    Map.show();
                });
            });
        },
        loadSvg: function(obj) {
            $("#"+obj.container).html('<object id="obj-'+obj.container+'" type="image/svg+xml" data="./data/' + obj.path + '" width="'+obj.width+'" height="'+obj.height+'" />');
            if(!this.lockPos) {
                Map.position = $("#"+obj.container+' object').offset();
                this.lockPos = true;
            }
            return true;
        },
        show: function() {
            Map.compassSvgDocument =  document.getElementById("obj-svgcompass");
            $.each(this.data, function(k,v) {
                $(Map.mapSvgDocument).find('path[id="'+k+'"]').css("fill-opacity", "0.9");
                $(Map.mapSvgDocument).find('path[id="'+k+'"]').css("fill", Main.root.outputresultcolor[parseInt(v)+1]);
                $(Map.mapSvgDocument).find('path[id="'+k+'"]').click(Main.onClickOrp);                
                $(Map.mapSvgDocument).find('path[id="'+k+'"]').mousemove(function(e){        
                    Map.onHover(e, k, v);
                }).css("cursor","pointer");
            });
            
            $('#svgmap').mouseout(function(e){        
                $('#wrap-orpinfo').hide();
            });
            /*
            Main.updateORP("Zlín", 2);
            Main.updateORP("Aš", 2);
            Main.updateORP("Mohelnice", 2);      
            */          
        },
        onHover: function(e, k, v) {
            if(!Main.showMapOrpInfo) return;
            $('#wrap-orpinfo').show();
            Main.viewUpdate({
                name: "orpinfo",
                sel: ".name",
                html: Main.root.orplist[k]
            });
            let hour = Main.appData.current.indexOfSampleName;
            let text = '';
            if(Main.data.advanceddata[hour][0][k]!=-1)
                text = Main.appData.current.selectData == "main"? ("<br>"+Main.data.advanceddata[hour][0][k]+"<br>"+Main.data.advanceddata[hour][1][k]+"<br>"+Main.data.advanceddata[hour][2][k] ):'';
            Main.viewUpdate({
                name: "orpinfo",
                sel: ".value",
                html: v+" : "+Main.appData.subtype.description1[String(v)]+text
            });
            $('#wrap-orpinfo img').hide();
            if(Main.appData.current.selectData == "secondary") {
                if(v>=0) {
                    Main.viewUpdateAttr({
                        name: "orpinfo",
                        sel: "img",
                        attr: "src",
                        val: "symbols/"+v+".png"
                    });
                    $('#wrap-orpinfo img').show();
                }    
            }
            $('#wrap-orpinfo').css({
                top: (this.position.top+e.pageY)+"px",
                left: (this.position.left+e.pageX)+"px"
            })
            return;
        }
    }    
} catch(e) {
    console.log(e);
}