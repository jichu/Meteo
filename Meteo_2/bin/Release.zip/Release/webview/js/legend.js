try {
    var Legend = {
        name: "legend",
        show: function(source) {
            Main.view({
                name: Legend.name,
                template: source
            });
        }
    }
} catch(e) {
    console.log(e);
}