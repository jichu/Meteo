try {
    var Header = {
        show: function(title) {
            Main.view("header");
            $(Main.container+" h1").html(title);
        }
    }
} catch(e) {
    console.log(e);
}