try {
    var OrpInfo = {
        name: "orpinfo",
        load: function() {
            Main.view(this.name);            
            $('#wrap-orpinfo').hide();
        }
    }
} catch(e) {
    console.log(e);
}