try {
    var Footer = {
        name: "footer",
        cols: 3,
        show: function(obj) {
            Main.view(this.name);
            this.createLinks(obj.links);
            
            Main.viewUpdate({
                name: Footer.name,
                sel: "footer .copyright-text",
                html: "&copy; "+new Date().getFullYear()+" "+Main.appData.copyright
            });
        },
        createLinks: function(obj) {
            let len = Object.keys(obj).length;
            Main.viewClear({
                name: Footer.name,
                sel: ".links-1"
            });
            Main.viewClear({
                name: Footer.name,
                sel: ".links-2"
            });
            Main.viewClear({
                name: Footer.name,
                sel: ".links-3"
            });

            let i = 0;
            let c = 0;
            $.each(obj, function(key,val) {
                if(i%3==0) 
                    c++;
                Main.viewUpdateAppend({
                    name: Footer.name,
                    sel: ".links-"+c,
                    html: Footer.setItem(key, val)
                });
                i++;
            });

        },
        setItem: function(text, href) {
            return '<li><a href="'+href+'" target="_blank" class="text-dark">'+text+'</a></li>';
        }
    }
} catch(e) {
    console.log(e);
}