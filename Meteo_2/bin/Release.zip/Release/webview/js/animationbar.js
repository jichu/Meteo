try {
    var AnimationBar = {
        name: "animationbar",
        show: function(obj) {
            Main.view({
                template: this.name,
                container: "#wrap-controlbar .column-right"
            });
            Main.viewUpdate({
                name: this.name,
                sel: ".label",
                html: obj.title
            });
            Main.viewUpdateAttr({
                name: this.name,
                sel: "input",
                attr: "max",
                val: obj.max
            });
            Main.viewUpdateAttr({
                name: this.name,
                sel: "input",
                attr: "value",
                val: obj.value
            });
            Main.viewUpdate({
                name: this.name,
                sel: ".time",
                html: obj.time
            });
            $('input').on('change', function(e){
                AnimationBar.eventIsChange(this);
            });
        },
        eventIsChange: function(obj) {
            Main.appData.current.indexOfSampleName = obj.value;
            Main.setCurrent();
            Main.run();
        }
    }
} catch(e) {
    console.log(e);
}