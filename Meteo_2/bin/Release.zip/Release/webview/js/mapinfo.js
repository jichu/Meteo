try {
    var MapInfo = {
        name: "mapinfo",
        show: function(obj) {
            Main.view(this.name);
            Main.viewUpdate({
                name: this.name,
                sel: ".date",
                html: obj.date
            });
            Main.viewUpdate({
                name: this.name,
                sel: ".time",
                html: obj.time
            });
            Main.viewUpdate({
                name: this.name,
                sel: ".name",
                html: obj.name
            });
        }
    }
} catch(e) {
    console.log(e);
}