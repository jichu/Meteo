var Main = {
    container: ".container",
    paths: {},
    htmlTemplate: {},
    appData: [],
    data: [],
    compassSvgDocument: null,
    svgMap: null,
    results: [],
    date: '',
    orpSelected: {
        name: "",
        direction: ""
    },
    showMapOrpInfo: true,
    init: function(paths) {
        this.paths = paths;
        this.paths.data = "data.json?"+_seed;
        this.getDate();
        let results = [
            this.loadComponents(),
            this.loadAppData(),
            this.loadData(),
            this.loadRoot(),
            this.loadLinks(),
        ];
        $.when.apply($, results).done(function() {
            console.log(Main.data);
            Main.run();
        });
        console.log(this.paths);
    },
    getDate: function() {
        let str = this.paths.data.replace('.json','');
        this.date = str.split('__')[2];
    },
    loadComponents: function() {
        let results = [];
        $.each(this.paths.components, function(k,v) {
            results.push(Main.comp(v));
       });
       return $.when.apply($, results);
    },
    comp: function(v) {
        return $.get("./components/"+v+"?"+_seed, function(html_string) {
            Main.htmlTemplate[v.replace(".html","")] = html_string;
        },'html');
    },
    loadData: function() {
        return $.getJSON("./data/"+this.paths.data+"?"+_seed, function(data) {
            Main.data = data;
        });
    },
    loadAppData: function() {
        return $.getJSON("./data/"+this.paths.app, function(data) {
            Main.appData = data;
        });
    },
    loadRoot: function() {
        return $.getJSON("./data/"+Main.paths.root+"?"+_seed, function(data) {
            console.log(data);
            Main.root = data;
        });
    },
    loadLinks: function() {
        return $.getJSON("./data/"+Main.paths.links, function(data) {
            Main.links = data;
        });
    },
    run: function() {
        this.getCurrent();
        Header.show(this.appData.title);
        let data = this.data.maindata[this.appData.current.indexOfSampleName][this.appData.current.indexOfMainData];
        if(Main.appData.current.selectData == "secondary")
            data = this.data.secondarydata[this.appData.current.indexOfSampleName][this.appData.current.indexOfSecondaryData-2];
        ControlBar.show();
        let hour = this.data.samplename[this.appData.current.indexOfSampleName];
        let date = this.data.date;
        if(hour>24) {
            hour -= 24;
            date = moment(date, "DD.MM.YYYY").add(1, 'days').format("DD.MM.YYYY");
        }
        AnimationBar.show({
            title: this.appData.animationBar+" | "+date,
            max: this.data.samplename.length-1,
            value: this.appData.current.indexOfSampleName,
            time: hour+"h"
        });
        MainOutputList.show($.merge($.merge([],this.root.mainoutputlist),this.root.secondaryoutputlist));
        OrpInfo.load();
        //SecondaryOutputList.show(this.root.secondaryoutputlist);
        MapInfo.show({
            date: "",
            time: this.data.majorconvectiontype[this.appData.current.indexOfSampleName],
            name: ""
        });
        Map.load(data);        
        TableOutput.show({
            "ORP": this.root.orplist, 
            "Hodnota": data
        });
        if(Main.appData.current.selectData == "main")
            Legend.show(this.appData.legend.main[this.appData.current.indexOfMainData]);
        if(Main.appData.current.selectData == "secondary")
            Legend.show(this.appData.legend.secondary[this.appData.current.indexOfSecondaryData-2]);
        Footer.show({links:this.links});
    },
    view: function(obj) {
        let name = null; 
        let template = null;
        let container = this.container;
        let sel = "";
        if(typeof obj === 'string') {
            name = obj;
            template = obj;
        }
        if(typeof obj === 'object') {
            name = isDefined(obj.name)?obj.name:obj.template;
            template = isDefined(obj.template)?obj.template:obj.name;
            container = isDefined(obj.container)?obj.container:container;
            sel = isDefined(obj.sel)?(' '+obj.sel):'';
        }
        if(name==null || template==null) return;
        $('#wrap-'+name).remove();
        $(name=="footer"?"body":container).append('<div id="wrap-'+name+'"></div>');
        $('#wrap-'+name+sel).append(Main.htmlTemplate[template]);
        
    },
    viewUpdate: function(obj) {
        $('#wrap-'+obj.name+' '+obj.sel).html(obj.html);   
    },
    viewUpdateAttr: function(obj) {
        $('#wrap-'+obj.name+' '+obj.sel).attr(obj.attr, obj.val);   
    },
    viewClear: function(obj) {
        $('#wrap-'+obj.name+' '+obj.sel).empty();   
    },
    viewUpdateAppend: function(obj) {
        $('#wrap-'+obj.name+' '+obj.sel).append(obj.html);   
    },
    setCurrent: function() {
        sessionStorage.setItem('appData.current', JSON.stringify(this.appData.current));
    },
    getCurrent: function() {
        if(sessionStorage.getItem('appData.current') == null) return;
        this.appData.current = $.parseJSON(sessionStorage.getItem('appData.current'));
    }
}