try {
    var SecondaryOutputList = {
        name: "secondary-select",
        show: function(list) {
            Main.view({
                name: SecondaryOutputList.name,
                template:"select",
                container: "#wrap-controlbar .column-left"
            });
            this.addOptions(list);
            $('#wrap-'+this.name+' select').on('change', function(e){
                SecondaryOutputList.eventIsChange(this);
            });
        },
        addOptions: function(arr) {
            let options = '';
            $.each(arr, function(i,item) {
                let s = i==Main.appData.current.indexOfSecondaryData?' selected': '';
                options += '<option '+s+' value="'+i+'">'+item+'</option>';
            });
            Main.viewUpdate({
                name: SecondaryOutputList.name,
                sel: "select",
                html: options
            });
        },
        eventIsChange: function(obj) {
            Main.appData.current.selectData = "secondary";
            Main.appData.current.indexOfSecondaryData = obj.selectedIndex;
            Main.setCurrent();
            Main.run();
        }
    }
} catch(e) {
    console.log(e);
}