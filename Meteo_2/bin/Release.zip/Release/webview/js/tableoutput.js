try {
    Array.prototype.max = function() {
        return Math.max.apply(null, this);
      };     
    Array.prototype.min = function() {
        return Math.min.apply(null, this);
    };
      
    var TableOutput = {
        container: "tableoutput",
        data: null,
        view: function(suf) {
            return $('#wrap-'+this.container+' '+suf);
        },
        show: function(data) {
            this.data = data;
            Main.view(this.container);
            TableOutput.view('').prepend(TableOutput.filterValues());
            this.createTable(data);
            $('#wrap-'+this.container+' select').on('change', function(e){
                TableOutput.eventIsChange(this);
            });
        },
        createTable: function(data) {
            TableOutput.view('tbody').empty();
            this.addHeader(Object.keys(data));
            if(typeof data.Hodnota == 'undefined') return;
            let orp = Object.keys(data)[0];
            let values = Object.keys(data)[1];
            let max = data[values].max();
            let min = data[values].min();
            $.each(data[values], function(i, item) {
                if(Main.appData.filterTableORPvalues == "max")
                    if(parseInt(item)<max) return true;
                if(Main.appData.filterTableORPvalues == "min")
                    if(parseInt(item)>min) return true;
                TableOutput.addRow([data[orp][i], item]);
            });
        },
        addHeader: function(col) {
            TableOutput.view('thead tr').empty();
            $.each(col, function(i, item) {
                TableOutput.view('thead tr').append('<th scope="col">'+item+'</th>');
            });
        },
        addRow: function(row) {
            let cols = '';
            $.each(row, function(i, col) {
                cols += TableOutput.addCol(col);
            });
            TableOutput.view('tbody').append('<tr>'+cols+'</tr>');
        },
        addCol: function(value) {
            if(isNaN(value))
                return '<td>'+value+'</td>';
            else 
                return '<td style="background-color:'+Main.root.outputresultcolor[parseInt(value)+1]+';width:10px"></td>';
        },
        filterValues: function() {
            return Main.htmlTemplate["filtervalues"];
        },
        eventIsChange: function(obj) {
            obj.selectedIndex;
            Main.appData.filterTableORPvalues = obj.value;
            Main.setCurrent();
            this.createTable(TableOutput.data);
        }
    }
} catch(e) {
    console.log(e);
}