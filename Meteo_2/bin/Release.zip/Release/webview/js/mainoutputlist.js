try {
    var MainOutputList = {
        name: "main-select",
        show: function(list) {
            Main.viewClear({
                name: MainOutputList.name
            });
            Main.view({
                name: MainOutputList.name,
                template:"select",
                container: "#wrap-controlbar .column-left"
            });
            this.addOptions(list);
            $('#wrap-'+this.name+' select').on('change', function(e){
                MainOutputList.eventIsChange(this);
            });
        },
        addOptions: function(arr) {
            let options = '';
            $.each(arr, function(i,item) {
                let s = i==Main.appData.current.indexOfMainData?' selected': '';
                if(Main.appData.current.selectData == "secondary")
                    s = i==Main.appData.current.indexOfSecondaryData?' selected': '';
                let css = (i<2)?'option-main':'option-secondary';
                options += '<option '+s+' value="'+i+'" class="'+css+'">'+item+'</option>';
            });
            Main.viewUpdate({
                name: MainOutputList.name,
                sel: "select",
                html: options
            });
        },
        eventIsChange: function(obj) {
            if(obj.selectedIndex<2) {
                Main.appData.current.selectData = "main";
                Main.appData.current.indexOfMainData = obj.selectedIndex;
            } else {
                Main.appData.current.selectData = "secondary";
                Main.appData.current.indexOfSecondaryData = obj.selectedIndex;
            }
            Main.setCurrent();
            Main.run();
        }
    }
} catch(e) {
    console.log(e);
}