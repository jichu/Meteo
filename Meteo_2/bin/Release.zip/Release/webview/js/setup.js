var Setup = {
    debug: false,
    direction: ["S", "SV", "V", "JV", "J", "JZ", "Z", "SZ"],
    directionColorActive: "#198754"
}