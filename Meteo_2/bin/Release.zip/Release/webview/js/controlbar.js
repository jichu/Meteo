try {
    var ControlBar = {
        name: "controlbar",
        show: function() {
            Main.view(this.name);
        }
    }
} catch(e) {
    console.log(e);
}